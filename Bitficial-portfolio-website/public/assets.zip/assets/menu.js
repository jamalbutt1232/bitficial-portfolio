
const menuLinks = document.querySelectorAll('nav a');
const menuToggle = document.querySelector('#check');


const ul = document.querySelector("nav ul");
var Id = document.getElementById('menulist');

const left = window.getComputedStyle(Id).left;
const lis = document.getElementById('menulist').getElementsByTagName('li');
 
for(let i=0;i<lis.length;i++){

    lis[i].addEventListener('click', function() {
      
      menuToggle.checked = false;
    });


}

